import React, { useState } from "react";
import { AiOutlineClose } from "react-icons/ai";

function Task(props) {
  const [task, setTask] = useState({
    id: props.id,
    title: props.title,
    description: props.description,
    date: props.date,
    tag: props.tag,
    tagColor: props.tagColor,
  });

  // Return table row with tasks attributes in different columns
  return (
    <tr className={`task-container ${task.tagColor}`}>
      <td>{task.title}</td>
      <td>{task.description}</td>
      <td>{task.date}</td>
      <td className="task-tags">{task.tag}</td>
      <td>
        <AiOutlineClose
          style={{ color: "white", cursor: "pointer" }}
          onClick={() => props.delete(props.id)}
        />
      </td>
    </tr>
  );
}

export default Task;
